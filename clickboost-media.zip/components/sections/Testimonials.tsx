import React from 'react';
import { Testimonial } from '../../types';

const testimonialsData: Testimonial[] = [
  {
    id: 1,
    quote: "ClickBoost Media transformed our online presence. Their SEO strategy doubled our organic traffic in just three months. Highly recommended!",
    author: "Sarah Johnson",
    company: "CEO, Lifestyle Co.",
    avatarUrl: "https://picsum.photos/seed/avatar1/100/100",
  },
  {
    id: 2,
    quote: "The social media campaigns they ran for us were a game-changer. Our engagement and lead generation have never been better. A truly professional team.",
    author: "Michael Chen",
    company: "Founder, Tech Startup",
    avatarUrl: "https://picsum.photos/seed/avatar2/100/100",
  },
  {
    id: 3,
    quote: "From branding to paid ads, ClickBoost has been an invaluable partner. They are creative, responsive, and genuinely care about our success.",
    author: "Emily Rodriguez",
    company: "Marketing Director, Fresh Foods Inc.",
    avatarUrl: "https://picsum.photos/seed/avatar3/100/100",
  },
];

const TestimonialCard: React.FC<{ testimonial: Testimonial; index: number }> = ({ testimonial, index }) => {
    const colors = ['text-blue-500', 'text-teal-500', 'text-yellow-500'];
    const color = colors[index % 3];

    return (
        <div className="bg-white p-8 rounded-lg shadow-lg flex flex-col h-full">
            <div className={`${color} mb-4`}>
                <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-9.57v7.068c-3.148 0-4.983 1.522-4.983 4.883v5.01h-4v-.002zm-12 0v-7.391c0-5.704 3.748-9.57 9-9.57v7.068c-3.148 0-5 1.522-5 4.883v5.01h-4z"/></svg>
            </div>
            <p className="text-gray-600 italic mb-6 flex-grow">"{testimonial.quote}"</p>
            <div className="flex items-center">
                <img src={testimonial.avatarUrl} alt={testimonial.author} className="w-14 h-14 rounded-full mr-4" />
                <div>
                    <p className="font-bold text-gray-800">{testimonial.author}</p>
                    <p className="text-sm text-gray-500">{testimonial.company}</p>
                </div>
            </div>
        </div>
    );
};


const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-100">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-500 tracking-widest uppercase">Client Reviews</h2>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mt-2">What Our Clients Say</h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-4">
            We thrive on our clients' success, and we're proud to share their feedback.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonialsData.map((testimonial, index) => (
                <TestimonialCard key={testimonial.id} testimonial={testimonial} index={index} />
            ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;