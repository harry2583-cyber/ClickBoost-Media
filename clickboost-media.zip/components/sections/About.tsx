import React from 'react';

const StatCard: React.FC<{ value: string; label: string; color: 'blue' | 'teal' }> = ({ value, label, color }) => {
    const colorClasses = {
        blue: 'bg-blue-50 text-blue-500',
        teal: 'bg-teal-50 text-teal-600',
    };
    return (
        <div className={`${colorClasses[color]} p-6 rounded-lg text-center shadow-md`}>
            <p className="text-4xl font-bold">{value}</p>
            <p className="text-gray-600 mt-2">{label}</p>
        </div>
    );
};

const About: React.FC = () => {
  return (
    <div className="py-20 bg-gradient-to-b from-white to-blue-50">
      <div className="container mx-auto px-6">
        
        {/* Main About Section */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div className="text-center md:text-left">
            <h2 className="text-sm font-bold text-blue-500 tracking-widest uppercase">Who We Are</h2>
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mt-2">Your Partner in Digital Excellence</h1>
            <p className="text-lg text-gray-600 mt-4">
              ClickBoost Media was founded with a simple mission: to help businesses of all sizes navigate the complex world of digital marketing and achieve tangible results. We are a team of passionate marketers, strategists, and creatives dedicated to your success.
            </p>
          </div>
          <div>
            <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&auto=format&fit=crop&q=60" 
                alt="A team of digital marketing experts collaborating" 
                className="rounded-lg shadow-xl" 
            />
          </div>
        </div>
        
        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <img src="https://picsum.photos/seed/vision/600/400" alt="Team discussing strategy" className="rounded-lg shadow-xl" />
          </div>
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Our Mission</h3>
              <p className="text-gray-600">
                To empower businesses with innovative and effective digital marketing strategies that drive growth, enhance brand visibility, and create lasting connections with their audience.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Our Vision</h3>
              <p className="text-gray-600">
                To be the most trusted and results-oriented digital marketing agency, known for our creativity, transparency, and unwavering commitment to client success.
              </p>
            </div>
             <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Our Values</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li><strong>Integrity:</strong> We operate with transparency and honesty.</li>
                  <li><strong>Innovation:</strong> We stay ahead of digital trends.</li>
                  <li><strong>Collaboration:</strong> We work as an extension of your team.</li>
                  <li><strong>Results:</strong> We are focused on delivering measurable success.</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <StatCard value="50+" label="Happy Clients" color="blue" />
            <StatCard value="200+" label="Projects Completed" color="teal" />
            <StatCard value="98%" label="Client Retention" color="blue" />
            <StatCard value="5M+" label="Ad Spend Managed" color="teal" />
        </div>

      </div>
    </div>
  );
};

export default About;