
import React from 'react';
import { BlogPost } from '../../types';

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: '5 SEO Trends to Watch in 2024',
    excerpt: 'The world of SEO is always changing. Stay ahead of the curve with these top 5 trends that will dominate search rankings this year...',
    date: 'July 15, 2024',
    author: 'Jane Doe',
    imageUrl: 'https://picsum.photos/seed/blog1/600/400'
  },
  {
    id: 2,
    title: 'The Ultimate Guide to Social Media Content Pillars',
    excerpt: 'Struggling with what to post? Discover how to create a solid content pillar strategy that keeps your audience engaged and your content calendar full.',
    date: 'July 10, 2024',
    author: 'John Smith',
    imageUrl: 'https://picsum.photos/seed/blog2/600/400'
  },
  {
    id: 3,
    title: 'Maximizing ROI with Google Ads: A Beginner\'s Guide',
    excerpt: 'Paid advertising can be intimidating. This guide breaks down the essentials of Google Ads to help you launch campaigns that convert without breaking the bank.',
    date: 'July 5, 2024',
    author: 'Emily White',
    imageUrl: 'https://picsum.photos/seed/blog3/600/400'
  },
];

const BlogCard: React.FC<{ post: BlogPost }> = ({ post }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden group">
        <img src={post.imageUrl} alt={post.title} className="w-full h-56 object-cover group-hover:opacity-80 transition-opacity" />
        <div className="p-6">
            <p className="text-sm text-gray-500 mb-2">{post.date} &bull; by {post.author}</p>
            <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-blue-500 transition-colors">{post.title}</h3>
            <p className="text-gray-600 mb-4">{post.excerpt}</p>
            <a href="#" className="font-semibold text-blue-500 hover:text-blue-600">Read More &rarr;</a>
        </div>
    </div>
);


const Blog: React.FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-500 tracking-widest uppercase">Insights & Articles</h2>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mt-2">From Our Blog</h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-4">
            Stay updated with the latest trends, tips, and insights from the world of digital marketing.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map(post => (
                <BlogCard key={post.id} post={post} />
            ))}
        </div>
      </div>
    </section>
  );
};

export default Blog;
