import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('submitting');
    const formData = new FormData(e.target as HTMLFormElement);

    try {
      const response = await fetch('https://formsubmit.co/ajax/harichandane555@gmail.com', {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      });

      if (response.ok) {
        setStatus('success');
        (e.target as HTMLFormElement).reset();
        setTimeout(() => setStatus('idle'), 5000); // Reset status after 5 seconds
      } else {
        setStatus('error');
        setTimeout(() => setStatus('idle'), 5000);
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setStatus('error');
      setTimeout(() => setStatus('idle'), 5000);
    }
  };

  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-500 tracking-widest uppercase">Contact Us</h2>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mt-2">Get in Touch</h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-4">
            Have a project in mind or just want to say hello? We'd love to hear from you.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 bg-white p-8 md:p-12 rounded-lg shadow-xl">
          {/* Contact Form */}
          <div>
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Send Us a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* formsubmit.co settings */}
              <input type="hidden" name="_captcha" value="false" />
              
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
                <input type="text" id="name" name="name" required className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                <input type="email" id="email" name="email" required className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                <textarea id="message" name="message" rows={5} required className="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
              </div>
              <div>
                <button
                  type="submit"
                  className="w-full bg-blue-500 text-white font-bold py-3 px-6 rounded-md hover:bg-blue-600 transition duration-300 shadow-lg disabled:bg-gray-400 disabled:cursor-not-allowed"
                  disabled={status === 'submitting'}
                >
                  {status === 'submitting' ? 'Submitting...' : 'Submit'}
                </button>
              </div>
            </form>
            {status === 'success' && (
              <p className="mt-4 text-center text-green-700 bg-green-100 p-3 rounded-md border border-green-200">
                Thank you for your message! We will get back to you shortly.
              </p>
            )}
            {status === 'error' && (
              <p className="mt-4 text-center text-red-700 bg-red-100 p-3 rounded-md border border-red-200">
                Oops! Something went wrong. Please try again later.
              </p>
            )}
          </div>

          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <img 
                  src="https://images.unsplash.com/photo-1596524430615-b46475ddff6e?w=1200&auto=format&fit=crop&q=60" 
                  alt="Contact us concept with phone and laptop"
                  className="rounded-lg shadow-md mb-8"
              />
            </div>
             <h3 className="text-2xl font-bold text-gray-800">Contact Information</h3>
            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 text-blue-500 rounded-full p-3 flex-shrink-0">
                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
              </div>
              <div>
                <h4 className="font-semibold text-lg">Our Office</h4>
                <p className="text-gray-600">Chhatrapati Sambhajinagar, Maharashtra</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-teal-100 text-teal-500 rounded-full p-3 flex-shrink-0">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
              </div>
              <div>
                <h4 className="font-semibold text-lg">Email Us</h4>
                <a href="mailto:harichandane555@gmail.com" className="text-gray-600 hover:text-blue-500">harichandane555@gmail.com</a>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-yellow-100 text-yellow-600 rounded-full p-3 flex-shrink-0">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
              </div>
              <div>
                <h4 className="font-semibold text-lg">WhatsApp</h4>
                <a href="https://wa.me/919225573225" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-blue-500">+91 9225573225</a>
              </div>
            </div>
          </div>
        </div>

        {/* Google Maps Embed */}
        <div className="mt-16 rounded-lg overflow-hidden shadow-xl">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d240184.7578200676!2d75.1442125191172!3d19.8801554489377!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdba38500000001%3A0x1759424888c34981!2sChhatrapati%20Sambhajinagar%2C%20Maharashtra%2C%20India!5e0!3m2!1sen!2sus!4v1721151659979!5m2!1sen!2sus"
            width="100%"
            height="450"
            style={{ border: 0 }}
            allowFullScreen={true}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Our Location"
          ></iframe>
        </div>
      </div>
    </section>
  );
};

export default Contact;