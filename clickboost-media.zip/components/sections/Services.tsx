import React from 'react';
import { Service } from '../../types';
import SocialMediaIcon from '../icons/SocialMediaIcon';
import SeoIcon from '../icons/SeoIcon';
import GmbIcon from '../icons/GmbIcon';
import PaidAdsIcon from '../icons/PaidAdsIcon';
import ContentMarketingIcon from '../icons/ContentMarketingIcon';
import BrandingIcon from '../icons/BrandingIcon';

const servicesData: Service[] = [
  {
    icon: <SocialMediaIcon />,
    title: 'Social Media Marketing',
    description: 'Engage your audience and build your brand on platforms like Instagram, Facebook, and LinkedIn with our expert social media strategies.'
  },
  {
    icon: <SeoIcon />,
    title: 'SEO',
    description: 'Climb the search engine rankings and attract organic traffic with our comprehensive on-page, off-page, and technical SEO services.'
  },
  {
    icon: <GmbIcon />,
    title: 'Google My Business',
    description: 'Optimize your local presence and attract nearby customers by mastering your Google My Business profile.'
  },
  {
    icon: <PaidAdsIcon />,
    title: 'Paid Ads',
    description: 'Get immediate, targeted traffic with expertly managed PPC campaigns on Google Ads, Meta, and other platforms.'
  },
  {
    icon: <ContentMarketingIcon />,
    title: 'Content Marketing',
    description: 'Attract and convert your target audience with high-quality, valuable content including blogs, videos, and infographics.'
  },
  {
    icon: <BrandingIcon />,
    title: 'Branding & Design',
    description: 'Create a memorable brand identity with our professional logo design, brand guidelines, and stunning visual assets.'
  },
];

const ServiceCard: React.FC<{ service: Service, index: number }> = ({ service, index }) => {
  const colors = [
    { bg: 'bg-blue-100', text: 'text-blue-500' },
    { bg: 'bg-teal-100', text: 'text-teal-500' },
    { bg: 'bg-yellow-100', text: 'text-yellow-600' }
  ];
  const color = colors[index % 3];

  return (
    <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 flex flex-col items-center text-center">
      <div className={`${color.bg} ${color.text} rounded-full p-4 mb-6`}>
        {service.icon}
      </div>
      <h3 className="text-xl font-bold text-gray-800 mb-3">{service.title}</h3>
      <p className="text-gray-600">{service.description}</p>
    </div>
  );
};


const Services: React.FC = () => {
  return (
    <section className="py-20 bg-slate-50 relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
          <img 
              src="https://images.unsplash.com/photo-1553877522-6424714d4554?w=1920&auto=format&fit=crop&q=60" 
              alt="Abstract background"
              className="w-full h-full object-cover opacity-[0.07]"
          />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-500 tracking-widest uppercase">Our Expertise</h2>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mt-2">What We Do</h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-4">
            We offer a full suite of digital marketing services to help your business grow online.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicesData.map((service, index) => (
            <ServiceCard key={index} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;