import React, { useState, useMemo } from 'react';
import { PortfolioItem, PortfolioCategory } from '../../types';

const portfolioData: PortfolioItem[] = [
  { id: 1, imageUrl: 'https://picsum.photos/seed/pf1/600/400', category: 'Posts', title: 'Aura Cosmetics - IG Campaign', description: 'Vibrant Instagram post series for a new cosmetic line.' },
  { id: 2, imageUrl: 'https://picsum.photos/seed/pf2/600/400', category: 'Posts', title: 'FreshEats - Food Photography', description: 'Mouth-watering content for a healthy meal delivery service.' },
  { id: 3, imageUrl: 'https://picsum.photos/seed/pf3/400/600', category: 'Reels', title: 'QuickCut - "How-To" Reel', description: 'Fast-paced tutorial video for a software company.' },
  { id: 4, imageUrl: 'https://picsum.photos/seed/pf4/600/400', category: 'Banners', title: 'TechCon 2024 - Event Banner', description: 'Promotional banner for a major tech conference.' },
  { id: 5, imageUrl: 'https://picsum.photos/seed/pf5/600/400', category: 'Websites', title: 'Fintech Solutions - Corporate Site', description: 'Sleek and professional website redesign for a financial tech company.' },
  { id: 6, imageUrl: 'https://picsum.photos/seed/pf6/600/400', category: 'Banners', title: 'GourmetBox - Display Ad Campaign', description: 'A series of high-CTR display ads for a subscription box.' },
  { id: 7, imageUrl: 'https://picsum.photos/seed/pf7/400/600', category: 'Reels', title: 'Wanderlust Travel - Destination Reel', description: 'Breathtaking travel reel that generated over 1M views.'},
  { id: 8, imageUrl: 'https://picsum.photos/seed/pf8/600/400', category: 'Websites', title: 'Artisan Coffee - E-commerce Store', description: 'A visually rich e-commerce platform that boosted online sales by 40%.'},
  { id: 9, imageUrl: 'https://picsum.photos/seed/pf9/600/400', category: 'Posts', title: 'UrbanFit - Carousel Ad', description: 'Engaging carousel post showcasing new apparel.' },
  { id: 10, imageUrl: 'https://picsum.photos/seed/pf10/600/400', category: 'Websites', title: 'LegalEase - Landing Page', description: 'High-converting landing page for a legal services firm.'}
];

const categories: PortfolioCategory[] = ['All', 'Posts', 'Reels', 'Banners', 'Websites'];

const Portfolio: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<PortfolioCategory>('All');
  
  const filteredPortfolio = useMemo(() => {
    if (activeCategory === 'All') {
      return portfolioData;
    }
    return portfolioData.filter(item => item.category === activeCategory);
  }, [activeCategory]);

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-500 tracking-widest uppercase">Our Work</h2>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mt-2">A Glimpse of Our Portfolio</h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-4">
            We're proud of the results we've delivered. Here's a selection of our recent projects.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex justify-center flex-wrap gap-2 mb-12">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full font-semibold transition-colors duration-300
                ${activeCategory === category 
                  ? 'bg-blue-500 text-white shadow-md' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPortfolio.map(item => (
            <div key={item.id} className="group relative overflow-hidden rounded-lg shadow-lg cursor-pointer">
              <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-70 transition-all duration-500 flex flex-col justify-end p-6">
                <h3 className="text-xl font-bold text-white opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">{item.title}</h3>
                <p className="text-gray-200 opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 delay-100">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;