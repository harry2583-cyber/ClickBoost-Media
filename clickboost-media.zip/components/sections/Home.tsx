import React from 'react';
import { Page } from '../../types';
import Testimonials from './Testimonials';

interface HomeProps {
    setActivePage: (page: Page) => void;
}

// Icon components for the new section
const DataIcon: React.FC = () => (
    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
);
const TeamIcon: React.FC = () => (
    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
);
const ResultsIcon: React.FC = () => (
    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 11l3-3m0 0l3 3m-3-3v8m0-13a9 9 0 110 18 9 9 0 010-18z" /></svg>
);


const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string; color: 'blue' | 'teal' | 'yellow' }> = ({ icon, title, description, color }) => {
    const colorClasses = {
        blue: 'bg-blue-100 text-blue-500',
        teal: 'bg-teal-100 text-teal-500',
        yellow: 'bg-yellow-100 text-yellow-600',
    };
    return (
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
            <div className={`flex items-center justify-center w-16 h-16 rounded-full ${colorClasses[color]} mb-4`}>
                {icon}
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
            <p className="text-gray-600">{description}</p>
        </div>
    );
};


const Home: React.FC<HomeProps> = ({ setActivePage }) => {

    const handleNavClick = (page: Page) => {
        setActivePage(page);
        window.scrollTo(0, 0);
    };

  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-slate-50 overflow-hidden">
        <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-96 h-96 bg-teal-200/50 rounded-full opacity-50 blur-2xl" aria-hidden="true"></div>
        <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-72 h-72 bg-yellow-200/50 rounded-full opacity-50 blur-2xl" aria-hidden="true"></div>

        <div className="container mx-auto px-6 py-20 md:py-32 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <div className="text-center md:text-left">
              <h1 className="text-4xl md:text-6xl font-extrabold text-gray-800 leading-tight mb-4 tracking-tighter">
                Grow Your Brand, <br />
                <span className="bg-gradient-to-r from-blue-500 to-teal-400 text-transparent bg-clip-text">
                  Boost Your Clicks
                </span>
              </h1>
              <p className="text-lg text-gray-600 mb-8 max-w-xl mx-auto md:mx-0">
                We are a results-driven digital marketing agency dedicated to helping your business thrive in the online world. From SEO to social media, we've got you covered.
              </p>
              <div className="flex justify-center md:justify-start space-x-4">
                <button onClick={() => handleNavClick('Contact')} className="bg-blue-500 text-white font-bold py-3 px-8 rounded-full hover:bg-blue-600 transition duration-300 transform hover:scale-105 shadow-lg">
                  Get a Free Quote
                </button>
                <button onClick={() => handleNavClick('Services')} className="bg-gray-200 text-gray-800 font-bold py-3 px-8 rounded-full hover:bg-gray-300 transition duration-300 transform hover:scale-105">
                  Our Services
                </button>
              </div>
            </div>
            {/* Image Content */}
            <div className="relative">
               <div className="absolute -top-4 -right-4 w-full h-full bg-yellow-300 rounded-lg transform rotate-3" aria-hidden="true"></div>
               <img 
                src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1200&auto=format&fit=crop&q=60" 
                alt="Digital marketing strategy and growth" 
                className="rounded-lg shadow-2xl relative z-10 transform transition-transform duration-500 hover:scale-105"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
              <div className="text-center mb-16">
                  <h2 className="text-sm font-bold text-blue-500 tracking-widest uppercase">Our Advantage</h2>
                  <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mt-2">Why Partner With Us?</h1>
                  <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-4">
                      We blend creativity with technology to deliver strategies that work.
                  </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <FeatureCard 
                      icon={<DataIcon />}
                      title="Data-Driven Strategies"
                      description="We leverage analytics and data to make informed decisions, ensuring every move is optimized for maximum impact and ROI."
                      color="blue"
                  />
                  <FeatureCard 
                      icon={<TeamIcon />}
                      title="Expert Team"
                      description="Our team consists of seasoned professionals who are passionate about digital marketing and dedicated to your brand's success."
                      color="teal"
                  />
                   <FeatureCard 
                      icon={<ResultsIcon />}
                      title="Proven Results"
                      description="We have a track record of delivering measurable results, from boosting traffic and leads to increasing conversions and revenue."
                      color="yellow"
                  />
              </div>
          </div>
      </section>

      {/* Testimonials Section */}
      <Testimonials />
    </>
  );
};

export default Home;