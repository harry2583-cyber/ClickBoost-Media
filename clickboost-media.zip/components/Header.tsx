
import React, { useState } from 'react';
import { Page } from '../types';

interface HeaderProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
  isScrolled: boolean;
}

const Logo: React.FC = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 48 56"
    className="w-10 h-10"
    aria-hidden="true"
  >
    <defs>
      <filter id="logo-glow" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="blur" />
      </filter>
    </defs>
    
    {/* Glow Effect */}
    <path
      d="M26 4 L42 18 H10 Z"
      fill="#FDB813"
      opacity="0.7"
      filter="url(#logo-glow)"
    />

    {/* Main Logo Shape */}
    <g fill="#1E90FF">
      {/* Arrow Head */}
      <path d="M26 4 L42 18 H10 Z" />
      {/* Arrow Shaft */}
      <rect x="20" y="18" width="12" height="12" />
      {/* Blocks */}
      <rect x="20" y="30" width="12" height="12" />
      <rect x="8" y="30" width="12" height="12" />
      <rect x="8" y="42" width="12" height="12" />
    </g>
    
    {/* Arrow Head Outline */}
    <path
      d="M26 4 L42 18 H10 Z"
      fill="none"
      stroke="#FDB813"
      strokeWidth="2"
      strokeLinejoin="round"
      strokeLinecap="round"
    />
  </svg>
);


const NavLink: React.FC<{
  page: Page;
  activePage: Page;
  onClick: (page: Page) => void;
  children: React.ReactNode;
  isMobile?: boolean;
}> = ({ page, activePage, onClick, children, isMobile = false }) => (
  <button
    onClick={() => onClick(page)}
    className={`
      ${isMobile ? 'block w-full text-left px-4 py-2 text-lg' : 'px-4 py-2'}
      font-semibold transition-colors duration-300 relative
      ${activePage === page 
        ? 'text-blue-500' 
        : 'text-gray-600 hover:text-blue-500'}
    `}
  >
    {children}
    {activePage === page && !isMobile && (
      <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-2/3 h-0.5 bg-blue-500 rounded-full"></span>
    )}
  </button>
);


const Header: React.FC<HeaderProps> = ({ activePage, setActivePage, isScrolled }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const pages: Page[] = ['Home', 'About', 'Services', 'Portfolio', 'Contact', 'Blog'];

  const handleNavClick = (page: Page) => {
    setActivePage(page);
    setIsMenuOpen(false);
    window.scrollTo(0, 0);
  };
  
  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/80 backdrop-blur-lg shadow-md' : 'bg-white'}`}>
      <div className="container mx-auto px-6 py-3 flex justify-between items-center">
        <button onClick={() => handleNavClick('Home')} className="flex items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500 rounded-lg group">
          <Logo />
          <span className="text-2xl font-bold ml-2 group-hover:text-gray-900 transition-colors" style={{color: '#0D244F'}}>ClickBoost Media</span>
        </button>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-2">
          {pages.map(page => (
            <NavLink key={page} page={page} activePage={activePage} onClick={handleNavClick}>
              {page}
            </NavLink>
          ))}
        </nav>
        
        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-700 focus:outline-none">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
              )}
            </svg>
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <nav className="flex flex-col py-4">
            {pages.map(page => (
              <NavLink key={page} page={page} activePage={activePage} onClick={handleNavClick} isMobile>
                {page}
              </NavLink>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
